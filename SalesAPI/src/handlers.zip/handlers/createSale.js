"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.main = void 0;
async function main(event) {
    return {
        statusCode: 200,
        body: JSON.stringify({
            message: "Hello World"
        })
    };
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3JlYXRlU2FsZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImNyZWF0ZVNhbGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBRU8sS0FBSyxVQUFVLElBQUksQ0FBQyxLQUEyQjtJQUNsRCxPQUFPO1FBQ0gsVUFBVSxFQUFFLEdBQUc7UUFDZixJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQztZQUNqQixPQUFPLEVBQUUsYUFBYTtTQUN6QixDQUFDO0tBQ0wsQ0FBQTtBQUNMLENBQUM7QUFQRCxvQkFPQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFQSUdhdGV3YXlQcm94eUV2ZW50IH0gZnJvbSBcImF3cy1sYW1iZGFcIjtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG1haW4oZXZlbnQ6IEFQSUdhdGV3YXlQcm94eUV2ZW50KSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICBtZXNzYWdlOiBcIkhlbGxvIFdvcmxkXCJcbiAgICAgICAgfSlcbiAgICB9XG59Il19