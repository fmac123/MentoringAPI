import { APIGatewayProxyEvent } from "aws-lambda";
export declare function main(event: APIGatewayProxyEvent): Promise<{
    statusCode: number;
    body: string;
}>;
